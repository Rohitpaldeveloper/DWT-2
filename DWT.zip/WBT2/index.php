<?php
?>

<!-- Index And Home Page Of Website -->
<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Rohit Pal Web-Template</title>
    <link rel="stylesheet" href="css/components.css">
    <link rel="stylesheet" href="css/icons.css">
    <link rel="stylesheet" href="css/responsee.css">
    <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="owl-carousel/owl.theme.css">
    <!-- CUSTOM STYLE -->      
    <link rel="stylesheet" href="css/template-style.css">
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@200;300;400;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Mrs+Saint+Delafield&display=swap" rel="stylesheet">  
    <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>   
  </head>

  <body class="size-1280 primary-color-red">
    <!-- PREMIUM FEATURES BUTTON -->
  	<a target="_blank" class="hide-s" href="../template/financer-premium-responsive-business-template/" style="position:fixed;top:140px;right:-14px;z-index:10;"><img src="img/premium-features.png" alt=""></a>
    
    <!-- HEADER -->
    <header role="banner" class="position-absolute">
      <!-- Top Bar -->
      <div class="top-bar full-width hide-s hide-m">
        <div class="right">
            <a href="tel:+91 XXXXX-XXXXX" class="text-white text-primary-hover">more info: +91 XXXXX-XXXXX</a> <span class="sep text-white">|</span> <a href="empiresharkk@gmail.com" class="text-white text-primary-hover">write us: empiresharkk@gmail.com</a>
        </div>  
      </div>    
      <!-- Top Navigation -->
      <nav class="background-transparent background-transparent-hightlight full-width sticky">
        <div class="s-12 l-2">
          <a href="index.html" class="logo">
            <!-- Logo White Version -->
            <img class="logo-white" src="img/scott-webb-bmmcfZqSjBU-unsplash.jpg" alt="">
            <!-- Logo Dark Version -->
            <img class="logo-dark" src="img/scott-webb-bmmcfZqSjBU-unsplash.jpg" alt="">
          </a>
        </div>
        <div class="top-nav s-12 l-10">
          
          <ul class="right chevron">
            <li><a href="index.php">Home</a></li>
            <li><a href="about-us.html">About</a></li>
            <li><a>Products</a>
              <ul>
                <li><a>Products 1</a>
                  <ul>
                    <li><a>Products 1 A</a></li>
                    <li><a>Products 1 B</a></li>
                  </ul>
                </li>
                <li><a>Products 2</a></li>
              </ul>
            </li>
            <li><a href="our-services.html">Our Services</a></li>
            <li><a href="our-history.html">Our History</a></li>
            <li><a href="gallery.html">Gallery</a></li>
            <li><a href="contact.html">Contact</a></li>
          </ul>
        </div>
      </nav>
    </header>
    
    <!-- MAIN -->
    <main role="main">    
      <!-- Main Carousel -->
      <header class="carousel-default owl-carousel carousel-main carousel-nav-white background-dark">
        
        <div class="item">
          <div class="s-12 center">
            <!-- For ZOOM effect add classes "background-image-zoom-out" or "background-image-zoom-in" -->
            <div class="section background-image-zoom-out">
              <!-- ZOOMED Carousel Image -->
              <div class="background-image background-image-object" style="background-image:url(img/h1.jpg)"></div>
                            
              <div class="line">
                <p class="animated-carousel-element text-strong text-white text-s-size-30 text-m-size-40 text-l-size-50 text-size-80 text-line-height-1 margin-bottom-40 margin-top-130">
                  Rohit Pal <span class="text-orange animated-carousel-element">Web-Developer</span> Makes<br>
                  Amazing Website
                </p>
                <div class="m-12 l-8">
                  <p class="animated-carousel-element text-white text-size-20 margin-bottom-30">
                   Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repudiandae nemo, sed deserunt porro blanditiis pariatur officia eveniet debitis suscipit vitae repellendus. Optio eum enim aut, suscipit adipisci voluptatibus. Laudantium praesentium aliquam pariatur repellat aperiam, cupiditate at provident animi ipsum quo deleniti porro nesciunt et fugiat repudiandae. Cum adipisci fugiat suscipit.
                  </p>
                  <a class="button text-white background-primary margin-bottom-60" href="about-us.html">About Us</a> <a class="button text-white background-orange margin-bottom-60" href="contact.html">Contact Us</a>
                </div>
              </div>

            </div>
          </div>
        </div>
        
        <div class="item">
          <div class="s-12 center">
            <!-- For ZOOM effect add classes "background-image-zoom-out" or "background-image-zoom-in" -->
            <div class="section background-image-zoom-out">
              <!-- ZOOMED Carousel Image -->
              <div class="background-image background-image-object" style="background-image:url(img/h2.jpg)"></div>
              
              <div class="line">
                <p class="animated-carousel-element text-strong text-white text-s-size-30 text-m-size-40 text-l-size-50 text-size-80 text-line-height-1 margin-bottom-40 margin-top-130">
                  Skills<span class="text-orange animated-carousel-element"> Html,Css,Js</span>&nbsp;PHP<br> 
                  & MySQL
                </p>
                <div class="m-12 l-8">
                  <p class="animated-carousel-element text-white text-size-20 margin-bottom-30">
                   Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repudiandae nemo, sed deserunt porro blanditiis pariatur officia eveniet debitis suscipit vitae repellendus. Optio eum enim aut, suscipit adipisci voluptatibus. Laudantium praesentium aliquam pariatur repellat aperiam, cupiditate at provident animi ipsum quo deleniti porro nesciunt et fugiat repudiandae. Cum adipisci fugiat suscipit.
                  </p>
                  <a class="button text-white background-primary margin-bottom-60" href="about-us-1.html">About Us</a> <a class="button text-white background-orange margin-bottom-60" href="contact-1.html">Contact Us</a>
                </div>
              </div>

            </div>
          </div>
        </div>
        
        <div class="item">
          <div class="s-12 center">
            <!-- For ZOOM effect add classes "background-image-zoom-out" or "background-image-zoom-in" -->
            <div class="section background-image-zoom-out">
              <!-- ZOOMED Carousel Image -->
              <div class="background-image background-image-object" style="background-image:url(img/h3.jpg)"></div>
              
              <div class="line">
                <p class="animated-carousel-element text-strong text-white text-s-size-30 text-m-size-40 text-l-size-50 text-size-80 text-line-height-1 margin-bottom-40 margin-top-130">
                  Live Projects <span class="text-orange animated-carousel-element">Php </span>And Many Languages<br>
                  Elements
                </p>
                <div class="m-12 l-8">
                  <p class="animated-carousel-element text-white text-size-20 margin-bottom-30">
                   Lorem ipsum dolor, sit amet consectetur adipisicing elit. Repudiandae nemo, sed deserunt porro blanditiis pariatur officia eveniet debitis suscipit vitae repellendus. Optio eum enim aut, suscipit adipisci voluptatibus. Laudantium praesentium aliquam pariatur repellat aperiam, cupiditate at provident animi ipsum quo deleniti porro nesciunt et fugiat repudiandae. Cum adipisci fugiat suscipit.
                  </p>
                  <a class="button text-white background-primary margin-bottom-60" href="about-us-1.html">About Us</a> <a class="button text-white background-orange margin-bottom-60" href="contact-1.html">Contact Us</a>
                </div>
              </div>

            </div>
          </div>
        </div>
                     
      </header>
      
      <!-- Section 1 -->
      <section class="section-top-padding background-white">      
        <div class="line">
          <h2 class="text-extra-strong text-size-80 text-m-size-40 margin-bottom-40">What We Do?</h2>
        </div>
        <div class="line">
          <div class="margin2x">
             <!-- Image 1 -->
             <a href="our-services-1.html" class="s-12 m-6 l-3 margin-m-bottom-30">
                <div class="image-with-hover-overlay">
                  <div class="image-hover-overlay background-dark"> 
                    <div class="image-hover-overlay-content padding">
                      <!-- Text -->
                      <p class="text-white">
                        <ul>
                          <li>Php Language</li>
                          <li>C Language</li>
                          <li>Java Language</li>
                          <li>C++ Language</li>
                        </ul></p>
                    </div> 
                  </div>  
                  <!-- Photo -->
                  <img src="img/w1.jpg"/>
                </div>                                                                                                                                                                                                              
                <div class="margin-top">                          
                  <!-- Title -->
                  <h3 class="text-strong">Books</h3>                                                                                                                                                                                                                                                                                                                                                                                
                </div>
             </a>
             
             <!-- Image 2 -->
             <a href="our-services-2.html" class="s-12 m-6 l-3 margin-m-bottom-30">
                <div class="image-with-hover-overlay">
                  <div class="image-hover-overlay background-dark"> 
                    <div class="image-hover-overlay-content padding">
                      <!-- Text -->
                      <p class="text-white">
                        <ul>
                          <li>Php Language</li>
                          <li>C Language</li>
                          <li>Java Language</li>
                          <li>C++ Language</li>
                        </ul></p>
                    </div> 
                  </div>  
                  <!-- Photo -->
                  <img src="img/w2.jpg"/>
                </div>                                                                                                                                                                                                              
                <div class="margin-top">                          
                  <!-- Title -->
                  <h3 class="text-strong">Games</h3>                                                                                                                                                                                                                                                                                                                                                                                
                </div>
             </a>
             
             <!-- Image 3 -->
             <a href="our-services-1.html" class="s-12 m-6 l-3 margin-m-bottom-30">
                <div class="image-with-hover-overlay">
                  <div class="image-hover-overlay background-dark"> 
                    <div class="image-hover-overlay-content padding">
                      <!-- Text -->
                      <p class="text-white">
                        <ul>
                          <li>Php Website</li>
                          <li>WordPress Website</li>
                          <li>Coding Website</li>
                          <li>C++ Language</li>
                        </ul>
                      </p>
                    </div> 
                  </div>  
                  <!-- Photo -->
                  <img src="img/w3.jpg"/>
                </div>                                                                                                                                                                                                              
                <div class="margin-top">                          
                  <!-- Title -->
                  <h3 class="text-strong">Web Design</h3>                                                                                                                                                                                                                                                                                                                                                                                
                </div>
             </a>
             
             <!-- Image 4 -->
             <a href="our-services-2.html" class="s-12 m-6 l-3 margin-m-bottom-30">
                <div class="image-with-hover-overlay">
                  <div class="image-hover-overlay background-dark"> 
                    <div class="image-hover-overlay-content padding">
                      <!-- Text -->
                      <p class="text-white">
                        <ul>
                          <li>Php Language</li>
                          <li>C Language</li>
                          <li>Java Language</li>
                          <li>C++ Language</li>
                        </ul>
                      </p>
                    </div> 
                  </div>  
                  <!-- Photo -->
                  <img src="img/w4.jpg"/>
                </div>                                                                                                                                                                                                              
                <div class="margin-top">                          
                  <!-- Title -->
                  <h3 class="text-strong">Projects</h3>                                                                                                                                                                                                                                                                                                                                                                                
                </div>
             </a>
          </div>                                                                                                
        </div>       
      </section>
      
      <!-- Section 2 -->
      <section class="section background-white">
        <div class="line">
          <h2 class="text-extra-strong text-size-80 text-m-size-40 margin-bottom-40">Who We Are?</h2>
        </div>
        <div class="line">
          <div class="margin2x">
            <div class="m-12 l-6">
              <h3 class="text-strong">Perfect Template for Business Website</h3>
              <p class="margin-bottom-30">Hendrerit in vulputate duis autem vel eum iriure dolor in velit esse molestie consequat, illum nulla facilisis. 
              Lorem ipsum dolor sit amet, vix purto suscipiantur conclusionemque eu, purto omittam accusata usu et, latine omittam expetendis no mei.
              </p>
              
              <!-- Icons -->              
              <div class="line">
                <div class="float-left">
                  <i class="icon-sli-cup icon2x text-primary"></i>
                </div>
                <div class="margin-left-50 margin-bottom-30">
                  <h3 class="text-strong">Web Template Designer</h3>
                  <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p>            
                </div>
              </div>
              
              <div class="line">
                <div class="float-left">
                  <i class="icon-sli-puzzle icon2x text-primary"></i>
                </div>
                <div class="margin-left-50 margin-bottom-30">
                  <h3 class="text-strong">Projects Development</h3>
                  <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p>            
                </div>
              </div>

            </div>
          
            <div class="m-12 l-6 margin-m-bottom-30">
              <!-- Image --> 
              <img src="img/b1.jpg" alt="">
            </div>          
            
          </div>    
        </div>  
      </section>
      
      <!-- Section 3 -->
      <section class="full-width background-grey">
        <div class="s-12 m-12 l-6">
          <!-- Image -->  
          <img src="img/b2.jpg" alt="">
        </div>
        <div class="s-12 m-12 l-6">
          <!-- Texts -->
          <div class="padding-2x">
            <div class="line"> 
                <h2 class="text-extra-strong text-size-80 text-m-size-40 margin-bottom-40">What about Accordion?</h2>
                <p class="text-dark text-size-20 margin-bottom-30">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p>
                
                <!-- Accordion -->
                <div class="accordion">
                  <!-- Accordion section -->    
                  <div class="accordion-section">		
                      <h2 class="accordion-title background-primary text-white">Interdum volutpat dis eget eligendi?</h2>								
                      <div class="accordion-content"> 
                        <p class="text-dark">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p>								                     	    		
                      </div>
                  </div>
                  <!-- Accordion section -->
                  <div class="accordion-section">		
                      <h2 class="accordion-title background-primary text-white">Claritas est etiam processus dynamicus?</h2>								
                      <div class="accordion-content"> 
                        <p class="text-dark">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p>								                     	    		
                      </div>
                  </div>
                  <!-- Accordion section -->
                  <div class="accordion-section">		
                      <h2 class="accordion-title background-primary text-white">Mutationem consuetudium lectorum?</h2>								
                      <div class="accordion-content"> 
                        <p class="text-dark">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p>								                     	    		
                      </div>
                  </div>
               </div>
              
            </div>
          </div>
        </div>
      </section>
      
      <!-- Section 4 -->
      <section class="section background-dark">  
        <div class="line">
          <h2 class="text-white text-extra-strong text-size-80 text-m-size-40 margin-bottom-40">Our Numbers</h2>
        </div>
        <div class="line">
          <div class="margin">
            <div class="s-12 m-12 l-3">
              <div class="block">
                <div class="count-to">
                  <span class="timer h1 text-size-60 text-orange">1500</span>
                  <p class="h1 text-size-20 margin-top-10 text-white text-thin">Demo</p> 
                </div>
              </div>
            </div>
            <div class="s-12 m-12 l-3">
              <div class="block">
                <div class="count-to">
                  <span class="timer h1 text-size-60 text-green">95</span> <span class="h1 text-size-60 text-green">%</span>
                  <p class="h1 text-size-20 margin-top-10 text-white text-thin">Accuracy</p> 
                </div>
              </div>
            </div>
            <div class="s-12 m-12 l-3">
              <div class="block">
                <div class="count-to">
                  <span class="timer h1 text-size-60 text-light-blue">287</span>
                  <p class="h1 text-size-20 margin-top-10 text-white text-thin">Projects</p> 
                </div>
              </div>
            </div>
            <div class="s-12 m-12 l-3">
              <div class="block">
                <div class="count-to">
                  <span class="timer h1 text-size-60 text-red">7</span> <span class="h1 text-size-60 text-red">milion</span>
                  <p class="h1 text-size-20 margin-top-10 text-white text-thin">Times Searches</p> 
                </div>
              </div>
            </div> 
          </div>
        </div>
      </section>
      
      
      <!-- Section 5 -->
      <section class="section-top-bottom-padding">  
        <div class="line">
          <h2 class="text-extra-strong text-size-80 text-m-size-40 margin-bottom-40">Our Projects</h2>
        </div>
        
        <!-- Image / Text Carousel -->
        <div class="carousel-center owl-carousel carousel-main carousel-hide-pagination nav-bottom text-center">
        
          <div class="item">
            <div class="image-with-text-overlay">
              <div class="image-text-overlay"> 
                <div class="image-text-overlay-content padding-2x">
                  <!-- Text -->
                  <p class="text-orange text-size-30 margin-bottom-10">01</p>
                  <h3 class="text-white text-size-30 text-strong">Unlimited Color Variants</h3>
                  <p class="text-white">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p> 
                </div> 
              </div>  
              <!-- Photo -->
              <img src="img/l1.jpg"/>
            </div>                                                                                                                                                                                                              
          </div>
          
          <div class="item">
            <div class="image-with-text-overlay">
              <div class="image-text-overlay"> 
                <div class="image-text-overlay-content padding-2x">
                  <!-- Text -->
                  <p class="text-orange text-size-30 margin-bottom-10">02</p>
                  <h3 class="text-white text-size-30 text-strong">Many Reusable Elements</h3>
                  <p class="text-white">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum! </p>  
                </div> 
              </div>  
              <!-- Photo -->
              <img src="img/l2.jpg"/>
            </div>                                                                                                                                                                                                              
          </div>
          
          <div class="item">
            <div class="image-with-text-overlay">
              <div class="image-text-overlay"> 
                <div class="image-text-overlay-content padding-2x">
                  <!-- Text -->
                  <p class="text-orange text-size-30 margin-bottom-10">03</p>
                  <h3 class="text-white text-size-30 text-strong">Responsive Layoute</h3>
                  <p class="text-white">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p>  
                </div> 
              </div>  
              <!-- Photo -->
              <img src="img/l3.jpg"/>
            </div>                                                                                                                                                                                                              
          </div>
          
          <div class="item">
            <div class="image-with-text-overlay">
              <div class="image-text-overlay"> 
                <div class="image-text-overlay-content padding-2x">
                  <!-- Text --> 
                  <p class="text-orange text-size-30 margin-bottom-10">04</p>
                  <h3 class="text-white text-size-30 text-strong">Clean Modern Code</h3>
                  <p class="text-white">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nulla magnam ipsa in illum eveniet quas, perspiciatis officiis accusantium autem aspernatur modi rerum cumque ex reiciendis explicabo sequi quibusdam placeat ipsam voluptatum nihil hic excepturi earum!</p>
                </div> 
              </div>  
              <!-- Photo -->
              <img src="img/l4.jpg"/>
            </div>                                                                                                                                                                                                              
          </div>
          
          <div class="item">
            <div class="image-with-text-overlay">
              <div class="image-text-overlay"> 
                <div class="image-text-overlay-content padding-2x">
                  <!-- Text --> 
                  <p class="text-orange text-size-30 margin-bottom-10">05</p>
                  <h3 class="text-white text-size-30 text-strong">Parallax Background</h3>
                  <p class="text-white">Lorem ipsum dolor si amet taciti sunt torquent ipsam proin montes quia netus quo minima sint. Con nonummy sem integer interdum volutpat dis eget eligendi aliquip dolorum magnam.</p>
                </div> 
              </div>  
              <!-- Photo -->
              <img src="img/l5.jpg"/>
            </div>                                                                                                                                                                                                              
          </div>
                       
        </div>
      </section>        
              
      
      <!-- Section 6 -->
      <section class="section-top-bottom-padding background-grey">      
        <div class="line">
          <h2 class="text-extra-strong text-size-80 text-m-size-40 margin-bottom-40">Our Team</h2>
        </div>
        
        <!-- Team Carousel -->                                                                                    
        <div class="carousel-blocks owl-carousel text-center">                                                                                              
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 1 -->
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!.</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Demo</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">CEO</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-google_plus_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-twitter_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                            
          </div> 
                       
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 2 -->                                                                                                                                                                                                                 
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Rohit Pal</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">Account Manager</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-google_plus_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                                                                                                                                                                                                                                                    
          </div> 
                       
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 3 -->                                                                                                                                                                                                      
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Ravinder</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">Sales Manager</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-twitter_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                           
          </div>  
                      
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 4 -->  
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!.</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Rahul</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">Sales Manager</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-google_plus_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-twitter_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                           
          </div> 
                       
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 5 -->                                                                                                                                                                                                        
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Prince</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">Office Manager</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-google_plus_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-twitter_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                             
          </div>
          
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 6 -->
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!.</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Robin</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">CEO</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-google_plus_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-twitter_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                            
          </div> 
                       
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 7 -->                                                                                                                                                                                                                 
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!.</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Riyaz</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">Account Manager</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-google_plus_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                                                                                                                                                                                                                                                    
          </div> 
                       
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 8 -->                                                                                                                                                                                                      
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!.</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Yugal</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">Sales Manager</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-twitter_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                           
          </div>  
                      
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 9 -->  
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Rahul</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">Sales Manager</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-google_plus_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-twitter_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                           
          </div> 
                       
          <div class="item">                                                                                                                                                                                                     
            <!-- Team Member 10 -->                                                                                                                                                                                                        
            <div class="image-with-hover-overlay">
              <div class="image-hover-overlay background-primary"> 
                <div class="image-hover-overlay-content padding">
                  <!-- Team Member Bio -->
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                </div> 
              </div>  
              <!-- Team Member Photo -->
              <img class="border-image border-primary" src="img/p1.jpg"/>
            </div>                                                                                                                                                                                                              
            <div class="margin-top">                          
              <!-- Team Member Description -->
              <h4 class="text-strong margin-bottom-10">Ankit</h4>                        
              <p class="margin-bottom-10 text-primary text-uppercase">Office Manager</p>                                                                                                                                          
              <div class="line">
                <a href="/"><i class="icon-linked_in_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-google_plus_circle text-primary-hover text-size-25"></i></a> <a href="/"><i class="icon-twitter_circle text-primary-hover text-size-25"></i></a>
              </div>                                                                                                                                                                                                                                          
            </div>                                                                                                                                                             
          </div>                                                                                                                          
        </div>                                                                                                                
      </section>

      
      <!-- Section 6 -->
      <section class="section background-image" style="background-image:url(img/parallax-04.jpg)">  
        <div class="line">
          <h2 class="text-white text-extra-strong text-size-80 text-m-size-40 margin-bottom-40"><span class="text-orange">Rohit</span> Pal</h2>
          <p class="text-white text-size-20 margin-bottom-30">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!
          </p>
          <p class="text-white text-handwrite text-size-50 margin-bottom-20">Do you need help?</p>
          <a class="button text-white background-orange" href="contact.html">Contact Our Team</a>  
        </div>
      </section>
      
      <!-- Section 7 -->
      <section class="section background-grey">      
        <div class="line">
          <div class="margin2x">
            <div class="s-12 m-12 l-6">
               
              <h3 class="text-size-40 text-m-size-25"><b>Satisfied</b> Clients</h3>
              <div class="carousel-default owl-carousel carousel-hide-arrows text-left">
                <div class="item">
                  <div class="s-12">
                    <div class="text-yellow margin-bottom-10"><i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i></div>
                    <p class="margin-bottom">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                    <p class="text-primary text-size-16"><strong>Scott Star</strong> / CEO / Company</p>
                  </div>
                </div>
                
                <div class="item">
                  <div class="s-12">
                    <div class="text-yellow margin-bottom-10"><i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i></div>
                    <p class="margin-bottom">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                    <p class="text-primary text-size-16"><strong>Mark Stoner</strong> / Web Developer / Company</p>
                  </div>
                </div>
                
                <div class="item">
                  <div class="s-12">
                    <div class="text-yellow margin-bottom-10"><i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i> <i class="icon-star text-size-12"></i></div>
                    <p class="margin-bottom">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                    <p class="text-primary text-size-16"><strong>Jane Naismith</strong> / Web Designer / Company</p>
                  </div>
                </div>
                
              </div>
               
            </div>
            <div class="s-12 m-12 l-6">
              <h3 class="text-size-40 text-m-size-25 margin-bottom-30">The Latest From <b>Our Blog</b></h3> 
              <div class="carousel-default owl-carousel carousel-hide-arrows text-left">
                <div class="item">
                  <div class="margin margin-bottom-30">
                    <div class="s-12 m-3 l-3">
                      <a class="image-hover-zoom margin-m-bottom-30" href="/">
                        <img src="img/img-02.jpg" alt="">
                      </a>  
                    </div>
                    <div class="s-12 m-9 l-9">
                      <h4><a class="text-dark text-primary-hover text-strong" href="/">Nam liber tempor cum soluta nobis eleifend</a></h4>
                      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                      <a class="text-more-info text-primary" href="/">Read more</a>
                    </div>  
                  </div> 
                </div>
                
                <div class="item">
                  <div class="margin margin-bottom-30">
                    <div class="s-12 m-3 l-3">
                      <a class="image-hover-zoom margin-m-bottom-30" href="/">
                        <img src="img/img-03.jpg" alt="">
                      </a>  
                    </div>
                    <div class="s-12 m-9 l-9">
                      <h4><a class="text-dark text-primary-hover text-strong" href="/">Nam liber tempor cum soluta nobis eleifend</a></h4>
                      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                      <a class="text-more-info text-primary" href="/">Read more</a>
                    </div>  
                  </div> 
                </div>
                
                <div class="item">
                  <div class="margin margin-bottom-30">
                    <div class="s-12 m-3 l-3">
                      <a class="image-hover-zoom margin-m-bottom-30" href="/">
                        <img src="img/img-04.jpg" alt="">
                      </a>  
                    </div>
                    <div class="s-12 m-9 l-9">
                      <h4><a class="text-dark text-primary-hover text-strong" href="/">Nam liber tempor cum soluta nobis eleifend</a></h4>
                      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quam, expedita blanditiis beatae quia cum natus nisi non ea enim est!</p>
                      <a class="text-more-info text-primary" href="/">Read more</a>
                    </div>  
                  </div> 
                </div>
                
              </div>
            </div>
          </div>
        </div>                                                                                     
      </section>
      
      <!-- Section 8 -->
      <section class="section background-white">
        <div class="line">
          <h2 class="text-extra-strong text-size-80 text-m-size-40 margin-bottom-40">Our Clients</h2>
        </div>   
        <div class="line-full-width">
          <div class="margin2x">
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
             <div class="m-6 l-1">
                <img class="margin-bottom" src="img/logo-1.png">
             </div>
          </div>
        </div>
          
        <!-- red full width arrow object -->
        <img class="arrow-object" src="img/object-red.svg" alt="">
      </section>

    </main>
    
    <!-- FOOTER -->
    <footer>
      <!-- Social -->
      <div class="background-primary padding text-center">
        <a href="/"><i class="icon-facebook_circle text-size-30 text-white"></i></a> 
        <a href="/"><i class="icon-twitter_circle text-size-30 text-white"></i></a>
        <a href="/"><i class="icon-google_plus_circle text-size-30 text-white"></i></a>
        <a href="/"><i class="icon-instagram_circle text-size-30 text-white"></i></a> 
        <a href="/"><i class="icon-linked_in_circle text-size-30 text-white"></i></a>                                                                       
      </div>
      <!-- Main Footer -->
      <section class="section background-dark">
        <div class="line"> 
          <div class="margin2x">
            <div class="hide-s hide-m hide-l xl-2">
               <img src="img/footer.jpg" alt="">
            </div>
            <div class="s-12 m-6 l-3 xl-3">
               <h4 class="text-white text-strong">Our Mission</h4>
               <p>
                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem error harum quia molestias ipsa, natus laborum voluptates suscipit pariatur ex..
               </p>
            </div>
            <div class="s-12 m-6 l-3 xl-2">
               <h4 class="text-white text-strong margin-m-top-30">Useful Links</h4>
               <a class="text-primary-hover" href="sample-post-without-sidebar.html">FAQ</a><br>      
               <a class="text-primary-hover" href="contact-1.html">Contact Us</a><br>
               <a class="text-primary-hover" href="blog.html">Blog</a>
            </div>
            <div class="s-12 m-6 l-3 xl-2">
               <h4 class="text-white text-strong margin-m-top-30">Term of Use</h4>
               <a class="text-primary-hover" href="sample-post-without-sidebar.html">Terms and Conditions</a><br>
               <a class="text-primary-hover" href="sample-post-without-sidebar.html">Refund Policy</a><br>
               <a class="text-primary-hover" href="sample-post-without-sidebar.html">Disclaimer</a>
            </div>
            <div class="s-12 m-6 l-3 xl-3">
               <h4 class="text-white text-strong margin-m-top-30">Contact Us</h4>
                <a class="text-primary-hover" href="tel:+91 XXXXX-XXXXX"><i class="icon-sli-screen-smartphone text-primary"></i> +91 XXXXX-XXXXX</a><br>
                <a class="text-primary-hover" href="empiresharkk@gmail.com"><i class="icon-sli-mouse text-primary"></i> empiresharkk@gmail.com</a><br>
                <a class="text-primary-hover" href="empiresharkk@gmail.com"><i class="icon-sli-mouse text-primary"></i> empiresharkk@gmail.com</a>
            </div>
          </div>  
        </div>    
      </section>
      <div class="background-dark">
        <hr class="break margin-top-bottom-0" style="border-color: #777;">
      </div>
      <!-- Bottom Footer -->
      <section class="padding-2x background-dark full-width">
        <div class="full-width">
          <div class="s-12 l-6">
            <p class="text-size-12 margin-bottom-0">Copyright 2022, Design By RohitPal</p>
            <p class="text-size-12">Copyright @ 2022 Terms & Conditions.</p>
          </div>
          <div class="s-12 l-6">
            <a class="right text-size-12 text-primary-hover" href="https://www.myresponsee.com" title="Responsee - lightweight responsive framework">Design and Coding<br> by Rohit Pal</a>
          </div>
        </div>  
      </section>
    </footer>
    <script type="text/javascript" src="js/responsee.js"></script>
    <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>
    <script type="text/javascript" src="js/template-scripts.js"></script> 
    
  </body>
</html>
